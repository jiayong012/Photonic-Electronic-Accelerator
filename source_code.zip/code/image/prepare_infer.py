import os 
def InfPrepare(save_folder = './results'):
    dep_name = './util/dep_name.txt'
    det_name = './util/det_name.txt'
    seg_name = './util/seg_name.txt'
    with open(dep_name, 'r') as file:
        lines = file.readlines()
    dep_name_list = [os.path.basename(line.strip()) for line in lines]
    with open(det_name, 'r') as file:
        lines = file.readlines()
    det_name_list = [os.path.basename(line.strip()) for line in lines]
    with open(seg_name, 'r') as file:
        lines = file.readlines()
    seg_name_list = [os.path.basename(line.strip()) for line in lines]

    # make folders to save results
    if not os.path.exists(save_folder+ '/depth'):
        os.makedirs(save_folder+'/depth')
    if not os.path.exists(save_folder+ '/detect'):
        os.makedirs(save_folder+ '/detect')
    if not os.path.exists(save_folder+'/segment'):
        os.makedirs(save_folder+'/segment')
    
    return dep_name_list, det_name_list, seg_name_list
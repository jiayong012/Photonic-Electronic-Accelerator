"""
This is the evaluation metrics for the detection, segmentation, and depth estimation tasks.
"""
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F

def iou_binary(preds, labels, EMPTY=1., ignore=255, per_image=True):
    """
    1 foreground, 0 background
    """
    if not per_image:
        preds, labels = (preds,), (labels,)
    ious = []
    for pred, label in zip(preds, labels):
        intersection = ((label == 1) & (pred == 1)).sum()
        if ignore != None:
            union = ((label == 1) | ((pred == 1) & (label != ignore))).sum()
        else :
            union = ((label == 1) | (pred == 1)).sum()

        if not union:
            iou = EMPTY
        else:
            iou = float(intersection) / float(union)
        ious.append(iou)
    iou = sum(ious) / len(ious) 

    return 100 * iou


def create_combined_mask(bbox_est, mask_shape=(400,400)):
    """
    Create a single binary mask where the regions covered by each bounding box
    in det_boxes_batch are set to 1 and the rest are set to 0.

    Parameters:
    - det_boxes_batch: List of bounding boxes (each as [x1, y1, x2, y2]).
    - mask_shape: Tuple defining the shape of the mask (height, width).

    Returns:
    - mask: A combined binary mask with regions covered by det_boxes_batch set to 1.
    """
    # Create an empty mask initialized to 0
    det_boxes_batch = (torch.round(bbox_est[0]*400).data.cpu().numpy()).astype(np.int32)
    combined_mask = np.zeros(mask_shape, dtype=np.uint8)

    # Set the regions covered by each bounding box to 1
    for box in det_boxes_batch:
        x1, y1, x2, y2 = int(box[0]), int(box[1]), int(box[2]), int(box[3])
        # Ensure coordinates are within mask boundaries
        x1 = max(0, min(x1, mask_shape[1]))
        y1 = max(0, min(y1, mask_shape[0]))
        x2 = max(0, min(x2, mask_shape[1]))
        y2 = max(0, min(y2, mask_shape[0]))
        combined_mask[y1:y2, x1:x2] = 1

    return combined_mask


def compute_mask_iou(bbox_est, bbox_gt):
    """
    Compute the IoU (Intersection over Union) between two binary masks.

    Parameters:
    - mask1: First binary mask.
    - mask2: Second binary mask.

    Returns:
    - iou: IoU value between the two masks.
    """
    mask1 = create_combined_mask(bbox_est)
    mask2 = create_combined_mask(bbox_gt)
    # Compute intersection and union
    intersection = np.logical_and(mask1, mask2).sum()
    union = np.logical_or(mask1, mask2).sum()
    # Compute IoU
    iou = intersection / union if union > 0 else 0.0
    return iou, mask1, mask2


# A positive constant scaling factor is adopted in RMSE loss to improve numerical stability and gradient Magnitude; and balance the multi-task optimization during training. Such scaling strategies are widely adopted in deep learning practice (e.g., 'Depth Map Prediction from a Single Image using a Multi-Scale Deep Network' (NIPS2014)), particularly in regression and multi-task settings, where loss re-weighting is commonly used to improve optimization dynamics without altering the theoretical objective.
# This RMSE is directly adopted as a evaluation metric for all methods, which is mathematically equivalent to the standard RMSE. 
class RMSE(nn.Module):
    def __init__(self):
        super(RMSE, self).__init__()
    
    def forward(self, fake, real):
        if not fake.shape == real.shape:
            _,_,H,W = real.shape
            fake = F.upsample(fake, size=(H,W), mode='bilinear')
        loss = torch.sqrt( torch.mean( torch.abs(10.*real-10.*fake) ** 2 ) )
        return loss
    
rmse_critor = RMSE()
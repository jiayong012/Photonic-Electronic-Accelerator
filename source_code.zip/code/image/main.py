import os 
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
import time
import numpy as np 
import torch
import cv2
import matplotlib.pyplot as plt
from colored_print import colored_print
from ParamNum import count_parameters
from prepare_infer import InfPrepare
from Evaluation_metrics import iou_binary, compute_mask_iou, rmse_critor

data_folder = '../../data/image'
chkpt_path = './ckpt/model.pt'
save_folder = '../../results/image'
dtype = torch.cuda.FloatTensor
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
dep_name_list, det_name_list, seg_name_list = InfPrepare(save_folder)

model = torch.jit.load(chkpt_path)
model.to(device)
model.eval()
param_num = count_parameters(model)

def model_inference():
    colored_print('Model inference on image for simultaneous object detection, segmentation, and depth estimation...', bold='b')
    IOU_det, n_det = [], []
    iou, n_seg = [], []
    rmse, n_dep = [], []
    # inference
    with torch.no_grad():
        for files in os.listdir(data_folder):
            ################# load data ################
            data_all = np.load(os.path.join(data_folder,files),allow_pickle=True)
            data_raw = data_all['im_rgb'] # only for visualizarion 
            data_loc = data_all['feat_loc'] # meatsurface extracted local feature
            data_glb = data_all['feat_glb'] # meatsurface extracted global feature
            data_edge = data_all['feat_edge'] # meatsurface extracted edge feature

            bbox = data_all['bbox_gt'] # detection GT bbox labels
            seg_gt = data_all['seg_gt'] # segmentation GT mask labels
            depth = data_all['depth_gt'] # GT depth maps

            ############################################################
            data_loc = torch.from_numpy(data_loc).unsqueeze(0).unsqueeze(0).type(dtype) 
            data_glb = torch.from_numpy(data_glb).unsqueeze(0).unsqueeze(0).type(dtype) 
            data_edge = torch.from_numpy(data_edge).unsqueeze(0).unsqueeze(0).type(dtype) 
            bbox_gt = [torch.from_numpy(bbox).to(device)] # list[1,[n_obj,4]]
            dep_gt = torch.from_numpy(depth).unsqueeze(0).unsqueeze(0).type(dtype)
            
            ################# draw GT detection bboxes ################
            data_raw_gtbbox = draw_box(data_raw.copy(), bbox_gt[0],color=(0,0,255))
            ################# draw GT segmentation masks ################
            data_raw_seg = draw_segdet(data_raw.copy(), seg_gt, type='S')
            
            # network forward, simultaneously get multiple vision results
            det_boxes_batch, seg_est, dep_est = model(data_loc, data_glb, data_edge)

            # detection results
            iou_det_t, _, _ = compute_mask_iou(det_boxes_batch,bbox_gt)
            IOU_det_data = (iou_det_t * 100)

            # segmentation results
            seg_mask = seg_est.squeeze(0).squeeze(0).data.cpu().numpy()
            seg_mask[seg_mask>0] = 1
            seg_mask[seg_mask<=0] = 0
            iou_data=(iou_binary(seg_mask.astype(np.uint8), seg_gt.astype(np.uint8), per_image=False))

            # depth results
            rmse_data = (rmse_critor(dep_est.unsqueeze(1), dep_gt.unsqueeze(1)).data.cpu().numpy())

            ############## save results #############
            if files[:-4] in det_name_list:
                ######################### detection results #########################
                im_out_det = draw_segdet(data_raw_gtbbox.copy(), seg_mask.astype(np.uint8), det_boxes_batch[0], type='D')
                out_name_det = save_folder + '/detect/' + files[:-4] +'_ioudet_' + str(IOU_det_data.round(1)) + '.png'
                cv2.imwrite(out_name_det, im_out_det)
                im_det_gt = data_raw_gtbbox.copy()
                name_det_gt = save_folder + '/detect/' + files[:-4] + '_det_gt.png'
                cv2.imwrite(name_det_gt, im_det_gt)
                IOU_det.append(IOU_det_data), n_det.append(files[:-4])

            if files[:-4] in seg_name_list:
                ######################## segmentation results ########################
                im_out_seg = draw_segdet(data_raw.copy(), seg_mask.astype(np.uint8),  type='S')
                out_name_seg = save_folder + '/segment/' + files[:-4] + '_iou_' + str(round(iou_data,1)) + '.png'
                cv2.imwrite(out_name_seg, im_out_seg)
                im_seg_gt = data_raw_seg.copy()
                name_seg_gt = save_folder + '/segment/' + files[:-4] + '_seg_gt.png'
                cv2.imwrite(name_seg_gt, im_seg_gt)
                iou.append(iou_data),  n_seg.append(files[:-4])

            if files[:-4] in dep_name_list:
                #################### depth results ########################
                out_name_dep = save_folder + '/depth/' + files[:-4] + '_rmse_' + str(rmse_data.round(2))+ '.png'
                fig = plt.figure(figsize=(2, 2), dpi=200)
                ax = fig.add_axes([0, 0, 1, 1])
                data_show = np.clip(dep_est.squeeze(0).squeeze(0).data.cpu().numpy(), 0,1)
                ax.imshow(data_show, cmap='viridis', aspect='auto')
                ax.axis('off')
                plt.savefig(out_name_dep, format='png')
                plt.close(fig)
                out_name_dep_gt = save_folder + '/depth/' + files[:-4] + '_dep_gt.png'
                fig = plt.figure(figsize=(2, 2), dpi=200)
                ax = fig.add_axes([0, 0, 1, 1])
                data_show = np.clip(dep_gt.squeeze(0).squeeze(0).data.cpu().numpy(), 0,1)
                ax.imshow(data_show, cmap='viridis', aspect='auto')
                ax.axis('off')
                plt.savefig(out_name_dep_gt, format='png')
                plt.close(fig)
                rmse.append(rmse_data), n_dep.append(files[:-4])

    colored_print(f'Model has parameters of: {param_num/1e3:.0f} K!', bold='b')
    colored_print('Model inference complete!', bold='b')
    colored_print(f'Results saved on {save_folder}', bold='b')



def draw_box(image, bbox, label=0, score=0, color=(255,255,255), bold=6):
    #bbox should be array in cuda [n_obj,4]
    bbox = (torch.round(bbox*400).data.cpu().numpy()).astype(np.int32)
    for i in range(bbox.shape[0]):
        cv2.rectangle(image, (bbox[i,0], bbox[i,1]), (bbox[i,2], bbox[i,3]), color, bold)

    return image


def draw_segdet(image, mask=None, bbox_est=None, type='D', color=(0,255,0)):
    if len(image.shape)==2:
        image_color = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    else:
        image_color = image

    if type == 'D':
        overlay = image_color
        # draw bbox
        bbox = (torch.round(bbox_est*400).data.cpu().numpy()).astype(np.int32)
        for i in range(bbox.shape[0]):
            cv2.rectangle(overlay, (bbox[i,0], bbox[i,1]), (bbox[i,2], bbox[i,3]), color, 6)
    elif type == 'S':
        color_mask = np.zeros_like(image_color)
        color_mask[np.where(mask == 1)] = [0, 0, 255]  
        alpha = 0.3
        # overlay images
        overlay = cv2.addWeighted(image_color, 1.0, color_mask, alpha, 0)
        # draw boundary
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, contours, -1, (0, 255, 0), 6)  
    else:
        color_mask = np.zeros_like(image_color)
        color_mask[np.where(mask == 1)] = [0, 0, 255]  
        alpha = 0.3
        # overlay images
        overlay = cv2.addWeighted(image_color, 1.0, color_mask, alpha, 0)
        # draw boundary
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, contours, -1, (0, 255, 0), 6)  
        # draw bbox
        bbox = (torch.round(bbox_est*400).data.cpu().numpy()).astype(np.int32)
        for i in range(bbox.shape[0]):
            cv2.rectangle(overlay, (bbox[i,0], bbox[i,1]), (bbox[i,2], bbox[i,3]), (255, 0, 0), 6)
    
    return overlay


if __name__ == '__main__':
    model_inference()
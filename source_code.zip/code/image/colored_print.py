# change color of print
color = {'red':'\033[31m', 'green': '\033[32m', 'yellow':'\033[33m', 'blue':'\033[34m'}
fbold = {'b':'\033[1m', 'rg':''}
reset = '\033[0m'

def colored_print(text, color_code='green', bold = 'rg'):
    print(f'{fbold[bold]}{color[color_code]}{text}{reset}')

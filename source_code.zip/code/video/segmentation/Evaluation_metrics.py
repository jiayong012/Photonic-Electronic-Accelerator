"""
This is the evaluation metrics for the segmentation task.
"""
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F

def iou_binary(preds, labels, EMPTY=1., ignore=255, per_image=True):
    """
    1 foreground, 0 background
    """
    if not per_image:
        preds, labels = (preds,), (labels,)
    ious = []
    for pred, label in zip(preds, labels):
        intersection = ((label == 1) & (pred == 1)).sum()
        if ignore != None:
            union = ((label == 1) | ((pred == 1) & (label != ignore))).sum()
        else :
            union = ((label == 1) | (pred == 1)).sum()

        if not union:
            iou = EMPTY
        else:
            iou = float(intersection) / float(union)
        ious.append(iou)
    iou = sum(ious) / len(ious) 

    return 100 * iou


def dice_coefficient(pred, target, threshold=0):
    pred = pred > threshold
    target = target > threshold
    intersection = (pred & target).float().sum((1, 2, 3))
    dice = (2. * intersection + 1e-6) / (pred.float().sum((1, 2, 3)) + target.float().sum((1, 2, 3)) + 1e-6)
    return 100 * dice.mean()

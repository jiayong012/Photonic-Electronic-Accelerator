import os 
import numpy as np 
import math
import torch
import cv2
from colored_print import colored_print
from Evaluation_metrics import iou_binary, dice_coefficient

data_folder = '../../../data/video'
save_folder = '../../../results/video/seg'
chkpt_path = './ckpt/model.pt'
if not os.path.exists(save_folder):
    os.makedirs(save_folder)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
dtype = torch.cuda.FloatTensor

model = torch.jit.load(chkpt_path)
model.to(device)
model.eval()

def model_inference():
    colored_print('Model inference on video segmentation...', bold='b')
    iou = []
    dice = []
    name_save = []
    # inference
    with torch.no_grad():
        for files in os.listdir(data_folder):
            data_name = os.path.join(data_folder,files)
            name_save.append(files)
            ################# load data ################
            data_all = np.load(data_name)
            data_raw = data_all['im_rgb'] # only for visualizarion 
            data_loc = data_all['feat_loc'][:,:,1:5] # meatsurface extracted local feature, 4 frames
            data_glb = data_all['feat_glb'][:,:,1:5] # meatsurface extracted global feature, 4 frames
            data_edge =data_all['feat_edge'][:,:,1:5] # meatsurface extracted edge feature, 4 frames
            seg_gt = data_all['seg_gt'] # segmentation GT mask labels

            ############################################################
            data_edge = torch.from_numpy(data_edge).permute(2,0,1).unsqueeze(0).type(dtype) 
            data_loc = torch.from_numpy(data_loc).permute(2,0,1).unsqueeze(0).type(dtype) 
            data_glb = torch.from_numpy(data_glb).permute(2,0,1).unsqueeze(0).type(dtype) 

            # network forward
            seg_est = model(data_loc, data_glb, data_edge)

            # segmentation results
            seg_mask = seg_est.squeeze(0).squeeze(0).data.cpu().numpy()
            seg_mask[seg_mask>0] = 1
            seg_mask[seg_mask<=0] = 0
            iou.append(iou_binary(seg_mask.astype(np.uint8), seg_gt.astype(np.uint8), per_image=False))
            dice.append(dice_coefficient(torch.from_numpy(seg_mask).unsqueeze(0).unsqueeze(0), torch.from_numpy(seg_gt).unsqueeze(0).unsqueeze(0)).numpy())

            # draw segmentation masks
            im_out = draw_seg(data_raw, seg_mask.astype(np.uint8))
            out_name = save_folder + '/' + files[:-4] + '_iou_' + str(round(iou[-1],1)) + '.png'
            cv2.imwrite(out_name, im_out)
            im_out = draw_seg(data_raw, seg_gt.astype(np.uint8))
            out_name = save_folder + '/' + files[:-4] + '_gt.png'
            cv2.imwrite(out_name, im_out)

    res = {'names': name_save, 'iou': iou, 'dice': dice}
    res_dir = save_folder + '/res.npz'
    np.savez_compressed(res_dir, **res)
    colored_print('Model inference complete!', bold='b')
    colored_print(f'Results saved on {save_folder}', bold='b')

def draw_seg(image, mask):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if len(image.shape)==2:
        image_color = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    else:
        image_color = image
    color_mask = np.zeros_like(image_color)
    color_mask[np.where(mask == 1)] = [0, 0, 255] 
    alpha = 0.3

    # overlay images
    overlay = cv2.addWeighted(image_color, 1.0, color_mask, alpha, 0)
    # draw boundary
    cv2.drawContours(overlay, contours, -1, (0, 255, 0), 6)  
    
    return overlay


if __name__ == '__main__':
    model_inference()
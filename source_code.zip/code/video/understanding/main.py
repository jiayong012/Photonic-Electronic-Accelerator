import os 
import math
import numpy as np 
import torch
import cv2
import model_fusionnet
from colored_print import colored_print

data_folder = '../../../data/video'
save_folder = '../../../results/video/cls'
chkpt_path = './ckpt/model.pt'
if not os.path.exists(save_folder):
    os.makedirs(save_folder)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
dtype = torch.cuda.FloatTensor

model = torch.jit.load(chkpt_path)
model.to(device)
model.eval()

def model_inference():
    colored_print('Model inference on video understanding...', bold='b')
    name_save = []
    # inference
    with torch.no_grad():
        for files in os.listdir(data_folder):
            name_save.append(files)
            data_name = os.path.join(data_folder,files)
            ################# load data ################
            data_all = np.load(data_name)
            data_loc = data_all['feat_loc'][:,:,:] # meatsurface extracted local feature, 5 frames
            data_glb = data_all['feat_glb'][:,:,:] # meatsurface extracted global feature, 5 frames
            data_edge =data_all['feat_edge'][:,:,:] # meatsurface extracted edge feature, 5 frames
            label_raw = int(data_all['cls_gt'])

            ############################################################
            data_edge = torch.from_numpy(data_edge).permute(2,0,1).unsqueeze(0).type(dtype) 
            data_loc = torch.from_numpy(data_loc).permute(2,0,1).unsqueeze(0).type(dtype) 
            data_glb = torch.from_numpy(data_glb).permute(2,0,1).unsqueeze(0).type(dtype) 

            # network forward
            cls_est = model(data_loc, data_glb, data_edge)

            #################### class results ####################
            colored_print(f'Understanding the video sample {files} as: {cls_est}!',color_code='yellow')


    colored_print('Model inference complete!', bold='b')
    colored_print(f'Results saved on {save_folder}', bold='b')
    


if __name__ == '__main__':
    model_inference()